import pygame

# === CONFIGURAÇÃO ===
pygame.init()
tela = pygame.display.set_mode((1480, 820))
pygame.display.set_caption("Dress Up")

# === CARREGAMENTO DE IMAGENS ===
def carregar_imagem(nome_arquivo, tamanho):
    imagem = pygame.image.load(nome_arquivo)
    return pygame.transform.scale(imagem, tamanho)

imagem_inicio = carregar_imagem("inicio_pixel.jpeg", (1480, 820))
imagem_principal = carregar_imagem("fundo_principaldef.jpg", (1480, 820))
imagem_terceira = carregar_imagem("fundo_final.jpeg", (1480, 820))

botao_avancar_img = carregar_imagem("avancar_image.png", (155, 80))
botao_voltar_img = carregar_imagem("voltar_image.png", (155, 80))
botao_salvar_img = carregar_imagem("salvar_image.png", (155, 80))

# === POSIÇÕES DOS BOTÕES ===
botao_play = pygame.Rect(510, 490, 460, 90)

pos_botao_avancar = (1300, 30)
ret_botao_avancar = pygame.Rect(pos_botao_avancar, botao_avancar_img.get_size())

pos_botao_voltar = (1300, 30)
ret_botao_voltar = pygame.Rect(pos_botao_voltar, botao_voltar_img.get_size())

pos_botao_salvar = (1300, 730)
ret_botao_salvar = pygame.Rect(pos_botao_salvar, botao_salvar_img.get_size())

# === FUNÇÕES DE CADA TELA ===
def mostrar_tela_inicio():
    tela.blit(imagem_inicio, (0, 0))
    pygame.display.update()

def mostrar_tela_principal():
    tela.blit(imagem_principal, (0, 0))
    tela.blit(botao_avancar_img, pos_botao_avancar)
    pygame.display.update()

def mostrar_terceira_tela():
    tela.blit(imagem_terceira, (0, 0))
    
    # Futuro: desenhar personagem montado aqui
    # tela.blit(personagem_montado, (x, y))

    tela.blit(botao_voltar_img, pos_botao_voltar)
    tela.blit(botao_salvar_img, pos_botao_salvar)
    pygame.display.update()

def salvar_imagem():
    nome_arquivo = "personagem_salvo.png"
    pygame.image.save(tela, nome_arquivo)
    print("Imagem salva como:", nome_arquivo)

# === LOOP PRINCIPAL DO JOGO ===
tela_atual = "inicio"

while True:
    if tela_atual == "inicio":
        mostrar_tela_inicio()

    elif tela_atual == "principal":
        mostrar_tela_principal()

    elif tela_atual == "terceira":
        mostrar_terceira_tela()

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            pygame.quit()
            exit()

        if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
            if tela_atual == "inicio":
                if botao_play.collidepoint(evento.pos):
                    tela_atual = "principal"

            elif tela_atual == "principal":
                if ret_botao_avancar.collidepoint(evento.pos):
                    tela_atual = "terceira"

            elif tela_atual == "terceira":
                if ret_botao_voltar.collidepoint(evento.pos):
                    tela_atual = "principal"
                elif ret_botao_salvar.collidepoint(evento.pos):
                    salvar_imagem()