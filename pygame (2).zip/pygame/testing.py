import pygame

# === CONSTANTES ===
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60

CHAR_WIDTH = 64
CHAR_HEIGHT = 64
CHAR_SCALE = 8

COR = (128, 128, 128)

pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Dress Game")
clock = pygame.time.Clock()
running = True

# === GÊNERO ===
current_gender = "m"  # "m" ou "f"
modo_vestido = False

# === CONTADORES ===
current_cabelo = 0
current_rosto = 0
current_roupa = 0
current_calca = 0
current_saia = 0

# === LOAD ESCALADO ===
def load_scaled(path):
    img = pygame.image.load(path).convert_alpha()
    return pygame.transform.scale(img, (CHAR_WIDTH * CHAR_SCALE, CHAR_HEIGHT * CHAR_SCALE))

# === ASSETS POR GÊNERO ===
def load_assets(genero):
    vazio = pygame.Surface((CHAR_WIDTH * CHAR_SCALE, CHAR_HEIGHT * CHAR_SCALE), pygame.SRCALPHA)

    return {
        "cabelo": [load_scaled(f"{'masc' if genero == 'm' else 'fem'}{i+1}.png") for i in range(3)],
        "rosto": [load_scaled(f"rosto{genero}{i+1}.png") for i in range(3)] + [vazio],  # último = semcabeca
        "roupa": [load_scaled(f"roupa{genero}{i+1}.png") for i in range(3)],
        "calca": [load_scaled(f"calca{genero}{i+1}.png") for i in range(3)],
        "saia": [load_scaled(f"saia{i+1}.png") for i in range(3)],
    }

assets = load_assets(current_gender)

# === BASE DO PERSONAGEM ===
char_img = load_scaled("pixil-frame-0.png")
char_x = SCREEN_WIDTH // 2 - (CHAR_WIDTH * CHAR_SCALE) // 2
char_y = SCREEN_HEIGHT // 2 - (CHAR_HEIGHT * CHAR_SCALE) // 2

# === LOOP PRINCIPAL ===
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_g:
                current_gender = "f" if current_gender == "m" else "m"
                assets = load_assets(current_gender)
                modo_vestido = False  # reseta

            if event.key == pygame.K_1:
                current_rosto = (current_rosto + 1) % 4
            if event.key == pygame.K_2:
                current_cabelo = (current_cabelo + 1) % 3
            if event.key == pygame.K_3:
                current_roupa = (current_roupa + 1) % 3
            if event.key == pygame.K_4:
                current_calca = (current_calca + 1) % 3
            if event.key == pygame.K_5:
                if current_gender == "f":
                    if not modo_vestido:
                        modo_vestido = True
                        current_saia = 0  # começa com a primeira saia
                    else:
                        current_saia = (current_saia + 1) % 3

    screen.fill(COR)

    screen.blit(char_img, (char_x, char_y))

    if modo_vestido and current_gender == "f":
        screen.blit(assets["saia"][current_saia], (char_x, char_y))
    else:
        screen.blit(assets["calca"][current_calca], (char_x, char_y))
        screen.blit(assets["roupa"][current_roupa], (char_x, char_y))

    screen.blit(assets["rosto"][current_rosto], (char_x, char_y))  # pode ser "semcabeca"
    screen.blit(assets["cabelo"][current_cabelo], (char_x, char_y))

    pygame.display.update()
    clock.tick(FPS)

pygame.quit()
